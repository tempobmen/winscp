This is the README file for standalone package of WinSCP for portable use.

For portable use of WinSCP see
http://winscp.net/eng/docs/portable

The package includes two executables, .exe and .com. For details see
http://winscp.net/eng/docs/executables

WinSCP homepage is http://winscp.net/

See the file 'license.txt' for the license conditions.
